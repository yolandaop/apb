<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Peminjaman_kelas extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('Mod_peminjaman_kelas','Mod_anggota','Mod_buku','Mod_laporan_kelas'));
    }

    public function index()
    {
        $data['transaksi_kelas']      = $this->Mod_peminjaman_kelas->getPeminjaman();
        // print_r($data['countanggota']); die();

        if($this->uri->segment(3)=="create-success") {
            $data['message'] = "<div class='alert alert-block alert-success'>
            <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
            <p><strong><i class='icon-ok'></i>Data</strong> Berhasil Disimpan...!</p></div>";    
            $this->load->view('includes/header');
            $this->load->view('peminjaman_kelas/tampilan_peminjaman', $data);  
        }
        else{
            $data['message'] = "";
            $this->load->view('includes/header');
            $this->load->view('peminjaman_kelas/tampilan_peminjaman', $data);  
        }
        
    }

    public function laporan()
    { 
        $data['title']="Laporan Pengembalian";
        $data['pengembalian_kelas']      = $this->Mod_laporan_kelas->getPengembalian();
        $this->load->view('includes/header');
        $this->load->view('laporan_kelas/transaksi_pengembalian', $data);     
    }

    public function peminjaman()
    {
        $data['tglpinjam']  = date('d-m-Y');
        $data['autonumber'] = $this->Mod_peminjaman_kelas->AutoNumbering();
        $data['anggota']    = $this->Mod_anggota->getAnggota()->result();
        $data['buku']    = $this->Mod_buku->getBuku()->result();
        $this->load->view('includes/header');
        $this->load->view('peminjaman_kelas/data_peminjaman', $data);
    }

    public function cari_anggota()
    {
        $nis = $this->input->post('nis');
        $cari = $this->Mod_anggota->cekAnggota($nis);
        //jika ada data anggota
        if($cari->num_rows() > 0) {
            $danggota = $cari->row_array();
            echo $danggota['nama'];
        }
    }


    public function cari_buku()
    {
        $caribuku = $this->input->post('caribuku');
        $data['buku'] = $this->Mod_buku->BookSearch($caribuku);
        $this->load->view('peminjaman_kelas/cari_buku_peminjaman', $data);
    }

    public function cari_judul()
    {
        //$bibid = 7611;
        $judul = $this->input->post('judul');
        $hasil = $this->Mod_buku->cekJudul($judul);
        //jika ada buku dalam database
        if($hasil->num_rows() > 0) {
            $dbuku = $hasil->row_array();
            echo $dbuku['bibid'];
        }
    }
   

    public function cari_bibid()
    {
        //$bibid = 7611;
        $bibid = $this->input->post('bibid');
        $hasil = $this->Mod_buku->cekBuku($bibid);
        //jika ada buku dalam database
        if($hasil->num_rows() > 0) {
            $dbuku = $hasil->row_array();
            echo $dbuku['judul'];
        }
    }


    public function simpan()
    {
        if(isset($_POST['save'])) {

            //function validasi

            //apabila user mengkosongkan form input
            if($this->form_validation->run()==false){
                // echo "masuk"; die();
                $nis = $this->input->post('nis');
                $data['tglpinjam']  = date('d-m-Y');
                $data['autonumber'] = $this->Mod_peminjaman_kelas->AutoNumbering();
                //cek idbuku yg sudah digunakan
                     $judul = slug($this->input->post('judul'));
                        $save  = array(
                            'id_transaksi' => $this->input->post('id_transaksi'),
                            'bibid' => $this->input->post('bibid'),
                            'judul' => $this->input->post('judul'),
                            'kelas' => $this->input->post('kelas'),
                            'nama' => $this->input->post('nama'),
                            'tanggal' => $this->input->post('tanggal'),
                            'jumlah' => $this->input->post('jumlah'),
                         );
                        $this->Mod_peminjaman_kelas->insertTransaksi('transaksi_kelas', $save);
                        // echo "berhasil"; die();
                        $bibid = $this->input->post('bibid');
                        $jumlah = $this->Mod_buku->getEksemplar($bibid) - $this->input->post('jumlah');

                        $dat = array(
                            'eksemplar' => $jumlah
                        );
                        $this->Mod_buku->updateBuku($bibid, $dat);
                         redirect('peminjaman_kelas/index/create-success');
                         $this->load->view('includes/header');
                         $this->load->view('peminjaman_kelas/tampilan_peminjaman', $data);                     
            }
            //jika tidak mengkosongkan form
            else{
                $data['message'] = "";
                $this->load->view('includes/header');
                $this->load->view('peminjaman_kelas/tampilan_peminjaman', $data);  
            }

        }
    }
      
    public function kembali()
    {
        //update status peminjaman dari N menjadi Y
        $id_transaksi = $this->uri->segment(3);
        $data = array(
            'status' => "kembali"
        );

        $bibid = $this->Mod_peminjaman_kelas->getBibid($id_transaksi);
        $jumlah = $this->Mod_peminjaman_kelas->getJumlah($bibid,$id_transaksi) + $this->Mod_buku->getEksemplar($bibid);
        $this->Mod_peminjaman_kelas->UpdateStatus($id_transaksi, $data);

        $dat = array(
            'eksemplar' => $jumlah
        );
        $this->Mod_buku->updateBuku($bibid, $dat);
        $data['transaksi_kelas']      = $this->Mod_peminjaman_kelas->getPeminjaman();
        $this->load->view('includes/header');
        $this->load->view('peminjaman_kelas/tampilan_peminjaman', $data); 
    }


        
}

/* End of file Peminjaman.php */
