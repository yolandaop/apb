<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan_kelas extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('Mod_laporan','Mod_anggota','Mod_buku','Mod_laporan_kelas'));
    }


}

/* End of file Laporan.php */
