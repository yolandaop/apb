<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Peminjaman extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('Mod_peminjaman','Mod_anggota','Mod_buku','Mod_laporan'));
    }

    public function index()
    {
        $data['transaksi']      = $this->Mod_peminjaman->getPeminjaman();
        // print_r($data['countanggota']); die();

        if($this->uri->segment(3)=="create-success") {
            $data['message'] = "<div class='alert alert-block alert-success'>
            <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
            <p><strong><i class='icon-ok'></i>Data</strong> Berhasil Disimpan...!</p></div>";    
            $this->load->view('includes/header');
$this->load->view('peminjaman/tampilan_peminjaman', $data);  
        }
        else if($this->uri->segment(3)=="update-success"){
            $data['message'] = "<div class='alert alert-block alert-success'>
            <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
            <p><strong><i class='icon-ok'></i>Data</strong> Berhasil Update...!</p></div>"; 
            $this->load->view('includes/header');
$this->load->view('peminjaman/tampilan_peminjaman', $data);  
        }
        else if($this->uri->segment(3)=="delete-success"){
            $data['message'] = "<div class='alert alert-block alert-success'>
            <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
            <p><strong><i class='icon-ok'></i>Data</strong> Berhasil Dihapus...!</p></div>"; 
            $this->load->view('includes/header');
$this->load->view('peminjaman/tampilan_peminjaman', $data);  
        }
        else{
            $data['message'] = "";
            $this->load->view('includes/header');
$this->load->view('peminjaman/tampilan_peminjaman', $data);  
        }
        
    }

    public function laporan()
    { 
        $data['title']="Laporan Pengembalian";
        $data['pengembalian']      = $this->Mod_laporan->getPengembalian();
        $this->load->view('includes/header');
        $this->load->view('laporan/transaksi_pengembalian', $data);
     
    }

    public function peminjaman()
    {
        $data['tglpinjam']  = date('d-m-Y');
        $data['autonumber'] = $this->Mod_peminjaman->AutoNumbering();
        $data['anggota']    = $this->Mod_anggota->getAnggota()->result();
        $this->load->view('includes/header');
        $this->load->view('peminjaman/data_peminjaman', $data);
    }

    public function tampil_tmp()
    {
        $data['tmp']       = $this->Mod_peminjaman->getTmp()->result();
        $data['jumlahTmp'] = $this->Mod_peminjaman->jumlahTmp();
        $this->load->view('peminjaman/peminjaman_tampil_tmp',$data);
    }

    public function cari_anggota()
    {
        $nama = $this->input->post('nama');
        $cari = $this->Mod_anggota->cekNama($nama);
        //jika ada data anggota
        if($cari->num_rows() > 0) {
            $danggota = $cari->row_array();
            echo $danggota['nis'];
        }
    }

    public function cari_buku()
    {
        $caribuku = $this->input->post('caribuku');
        $data['buku'] = $this->Mod_buku->BookSearch($caribuku);
        $this->load->view('peminjaman/peminjaman_searchbook', $data);
        // foreach($data['buku'] as $d) {
        //     print_r($d); die();
        // }
    }

    public function cari_bibid()
    {
        //$bibid = 7611;
        $bibid = $this->input->post('bibid');
        $hasil = $this->Mod_buku->cekBuku($bibid);
        //jika ada buku dalam database
        if($hasil->num_rows() > 0) {
            $dbuku = $hasil->row_array();
            echo $dbuku['judul'];
        }
    }

    public function save_tmp()
    {
        // $kode = $this->Mod_peminjaman->getTransaksi()->result_array();
        
        // if($kode->num_rows()==1) {
        //     echo "sudah ada";
        // }
        // else{

            $bibid = $this->input->post('bibid');
            // echo $bibid; die();
            $cek = $this->Mod_peminjaman->cekTmp($bibid);
            //cek apakah data masih kosong di tabel tmp
            if($cek->num_rows() < 1) {
                $data = array(
                    'bibid' => $this->input->post('bibid'),
                    'judul'     => $this->input->post('judul'),
                );
                $this->Mod_peminjaman->InsertTmp($data);
            }
    
        //}


    }

    public function hapus_tmp()
    {
        $bibid = $this->input->post('bibid');
        $this->Mod_peminjaman->deleteTmp($bibid);
    }

    public function simpan_transaksi()
    {
       
        //ambil data tmp lakukan looping . setelah looping lakukan insert ke table transaksi
        $table_tmp = $this->Mod_peminjaman->getTmp()->result();
        foreach($table_tmp as $data){

            $bibid = $data->bibid;
            $judul = $data->judul; 
            
            $data = array(
                'id_transaksi'     => $this->input->post('id_transaksi'),
                'nis'              => $this->input->post('nis'),
                'bibid'        => $data->bibid,
                'judul'        => $data->judul,
                'tanggal_pinjam'   => $this->input->post('tgl_pinjam')
            );
            $jumlah = $this->Mod_buku->getEksemplar($bibid) - 1;

            $dat = array(
                'eksemplar' => $jumlah
            );
            $this->Mod_buku->updateBuku($bibid, $dat);
           // print_r($data);
           
            //insert data ke table transaksi
            $this->Mod_peminjaman->InsertTransaksi($data); 
            

            //hapus table tmp
            $this->Mod_peminjaman->deleteTmp($bibid);
           
        }
    }

    public function kembali()
    {
        //update status peminjaman dari N menjadi Y
        $id_transaksi = $this->uri->segment(3);
        
        $data = array(
            'tanggal_kembali' => date('d-m-Y'),
            'status' => "kembali"
        );
        
        $bibid = $this->Mod_peminjaman->getBibid($id_transaksi);
        foreach($bibid as $id){
            $kode = $id->bibid;
            $jumlah = 1 + $this->Mod_buku->getEksemplar($kode);
            $dat = array(
                'eksemplar' => $jumlah
            );
        $this->Mod_buku->updateBuku($kode, $dat);
        $this->Mod_peminjaman->UpdateStatus($id_transaksi,$kode, $data);
        }
        $data['transaksi']      = $this->Mod_peminjaman->getPeminjaman();
        $this->load->view('includes/header');
        $this->load->view('peminjaman/tampilan_peminjaman', $data); 
    }
    



}

/* End of file Peminjaman.php */
