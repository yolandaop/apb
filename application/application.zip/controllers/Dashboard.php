<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('Mod_anggota','Mod_buku','Mod_peminjaman','Mod_peminjaman_kelas'));
    }

    function index()
    {
        $data['countanggota'] = $this->Mod_anggota->totalRows('anggota');
        
        $data['countbuku'] = $this->Mod_buku->totalRows('buku');

        $this->load->view('includes/header');
        $this->load->view('dashboard/tampilan_dashboard.php', $data); 
    }
        
    


}
/* End of file Controllername.php */
 