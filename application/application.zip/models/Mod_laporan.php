<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Mod_laporan extends CI_Model {

    
    private $table   = "pengembalian";

    public function searchPinjaman($tanggal1, $tanggal2)
    {
        // $this->db->select('*');
        // $this->db->from('transaksi');
        // $this->db->where('tanggal_pinjam <','$tanggal1');
        // $this->db->where('tanggal_kembali >','$tanggal2');

        // return $this->db->get();
        return $this->db->query("SELECT a.*, 
                                 FROM transaksi a WHERE a.tanggal_pinjam  BETWEEN '$tanggal1' AND '$tanggal2' GROUP BY a.id_transaksi");
    }   
    
    public function detailPinjaman($id_transaksi)
    {
        // $this->db->select("*");
        // $this->db->from("transaksi a");
        // $this->db->where("a.id_transaksi", $id_transaksi);
        // $this->db->join("buku b", "a.bibid = b.bibid");
        // return $this->db->get();
        return $this->db->query("SELECT a.*,b.bibid,b.judul, 
                                
                                 FROM transaksi a, buku b 
                                 WHERE a.id_transaksi = '$id_transaksi' 
                                 AND a.bibid = b.bibid");
    }

    public function searchPengembalian($tanggal1, $tanggal2)
    {
        return $this->db->query("SELECT * FROM pengembalian WHERE tgl_pengembalian BETWEEN '$tanggal1' AND '$tanggal2' GROUP BY id_transaksi");
    }

    public function detailPengembalian($id_transaksi)
    {
        return $this->db->query("SELECT a.*, c.bibid, c.judul, 
                                FROM pengembalian a, transaksi b, buku c
                                WHERE a.id_transaksi = '$id_transaksi'
                                AND a.id_transaksi = b.id_transaksi
                                AND b.bibid = c.bibid");
    }

        
    function totalRows($table)
	{
		return $this->db->count_all_results($table);
    }

    
    function getAll()
    {
        $this->db->order_by('pengembalian.tgl_pengembalian desc');
        return $this->db->get('pengembalian');
    }
    
    function getPengembalian()
    {
        $this->db->where('transaksi.status = "kembali"');
        $this->db->order_by('transaksi.id_transaksi desc');
        return $this->db->get('transaksi');
    }
}

/* End of file Mod_laporan.php */
