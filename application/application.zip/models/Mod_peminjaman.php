<?php 


defined('BASEPATH') OR exit('No direct script access allowed');

class Mod_peminjaman extends CI_Model 
{

    private $table = "transaksi";
    private $tmp   = "tmp";
    
    function AutoNumbering()
    {
        $today = date('Ymd');

        $data = $this->db->query("SELECT MAX(id_transaksi) AS last FROM $this->table ")->row_array();

        $lastNoFaktur = $data['last'];
        
        $lastNoUrut   = substr($lastNoFaktur,8,3);
        
        $nextNoUrut   = $lastNoUrut+1;
        
        $nextNoTransaksi = $today.sprintf('%03s',$nextNoUrut);
        
        return $nextNoTransaksi;
    }

    function getTmp()
    {
        return $this->db->get("tmp");
    }

    function getAll()
    {
        $this->db->order_by('transaksi.id_transaksi desc');
        return $this->db->get('transaksi');
    }

    
    function cekTmp($kode)
    {
        $this->db->where("bibid",$kode);
        return $this->db->get("tmp");
    }

    function InsertTmp($data)
    {
        //$this->db->insert("transaksi",$info);
        $this->db->insert($this->tmp, $data);    
    }

    function InsertTransaksi($data)
    {
        $this->db->insert($this->table, $data);
    }

    function getPeminjaman()
    {
        $this->db->where('transaksi.status = "dipinjam"');
        $this->db->order_by('transaksi.id_transaksi desc');
        return $this->db->get('transaksi');
    }

        
    public function UpdateStatus($id_transaksi,$bibid, $data)
    {
        $this->db->where("id_transaksi", $id_transaksi);
        $this->db->where("bibid", $bibid);
        $this->db->update($this->table, $data);
        
    }

    function jumlahTmp()
    {
        return $this->db->count_all("tmp");
    }

    function deleteTmp($bibid)
    {
        $this->db->where("bibid",$bibid);
        $this->db->delete($this->tmp);
    }

    function getTransaksi()
    {
        return $this->db->get($this->table);
    }

    function getBibid($id_transaksi)
    {
        $this->db->where("id_transaksi",$id_transaksi);
        return $this->db->get("transaksi")->result();
    }

}

/* End of file Mod_peminjaman.php */
