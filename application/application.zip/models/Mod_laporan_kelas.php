<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Mod_laporan_kelas extends CI_Model {

    private $table   = "pengembalian_kelas";


    public function searchPengembalian($tanggal1, $tanggal2)
    {
        return $this->db->query("SELECT * FROM pengembalian_kelas WHERE tgl_pengembalian BETWEEN '$tanggal1' AND '$tanggal2' GROUP BY id_transaksi");
    }

    function getPengembalian()
    {
        $this->db->where('transaksi_kelas.status = "kembali"');
        $this->db->order_by('transaksi_kelas.id_transaksi desc');
        return $this->db->get('transaksi_kelas');
    }
    
    function totalRows($table)
	{
		return $this->db->count_all_results($table);
    }

    
    function getAll()
    {
        $this->db->order_by('pengembalian_kelas.tgl_pengembalian desc');
        return $this->db->get('pengembalian_kelas');
    }

    function insertBuku($tabel, $data)
    {
        $insert = $this->db->insert($tabel, $data);
        return $insert;
    }

    function cekBuku($kode)
    {
        $this->db->where("bibid", $kode);
        return $this->db->get("buku");
    }

    function cekJudul($kode)
    {
        $this->db->where("judul", $kode);
        return $this->db->get("buku");
    }

    function updateBuku($bibid, $data)
    {
        $this->db->where('bibid', $bibid);
		$this->db->update('buku', $data);
    }


    function deleteBuku($kode, $table)
    {
        $this->db->where('bibid', $kode);
        $this->db->delete($table);
    }
    
}

/* End of file Mod_laporan.php */
